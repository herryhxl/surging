﻿namespace FileLoder.Templates
{
    public partial class IBaseContextTemplate
    {
        private readonly string _projectName;

        public IBaseContextTemplate(string projecctName)
        {
            _projectName = projecctName;
        }
    }
}