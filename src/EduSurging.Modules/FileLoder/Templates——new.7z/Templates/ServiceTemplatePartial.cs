﻿using System.Collections.Generic;
using System.Linq;
using FileLoder.TemplateModel;

namespace FileLoder.Templates
{
    public partial class ServiceTemplate
    {
        private readonly string _entityName;
        private readonly string _projectName;
        private readonly List<ColumnsModel> _sModels;
        private readonly TableModel models;
        private readonly string _repositoryText;
        private readonly bool _pro;

        public ServiceTemplate(string projectName, string entityName, List<ColumnsModel> sModels, TableModel Models,string repositoryText,bool pro)
        {
            _projectName = projectName;
            _entityName = entityName;
            _sModels = sModels;
            models = Models;
            _repositoryText = repositoryText;
            _pro = pro;
        }
    }
}